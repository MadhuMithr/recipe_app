import React from "react";
import "./Toastcontainer.css"
const ToastContainer=({text})=>
{
 return  <h1 className="styl">{text}</h1>
}
export default ToastContainer;

