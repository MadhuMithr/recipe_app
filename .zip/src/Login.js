import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {useDispatch ,useSelector} from "react-redux"
import './Login.css';
import {setEmaillog,setPasswordlog} from './store/loginslice'
const Login=()=>
{
   
    // const  mailid=useSelector((state)=>{state.log.email});
    // const pass=useSelector((state)=>{state.log.password});
   const dispatch=useDispatch();
   const handleNaviagtion=()=>
    {
       
              dispatch(setEmaillog(email));
              dispatch(setPasswordlog(password));
    navi("/");
    // localStorage.setItem("email",email);
    //     localStorage.setItem("password",password);

   }
    const [email,setEmail]=useState("");
    const [password,setPassword]=useState("");
    const navi=useNavigate();
    useEffect(()=>{
          const useremail=localStorage.getItem("email");
    const userpass=localStorage.getItem("password");
     if( useremail && userpass)
        { navi("/")};

    },[navi]);
    return(
        <div className="container">
            <h1>Enter your e-mail id</h1>
            <input type="email" onChange={(e)=>{setEmail(e.target.value)}}></input>
            <h1>Enter your password</h1>
            <input type="password" onChange={(e)=>{setPassword(e.target.value)}}></input>
            {
                console.log(email+" "+password)
            }
            <button id="buttonfix" onClick={handleNaviagtion}>LOGIN</button>
        </div>
    )
}
export default Login;