import {createSlice } from '@reduxjs/toolkit'
const initialState ={
        email : "",
        password : "",
        
    }
export const  loginslice = createSlice({
    name : 'loginsli',
    initialState:initialState,
    reducers:{
        setEmaillog:(state,action)=>
        {
            state.email=action.payload
        },
        setPasswordlog :(state,action)=>
        {
            state.password=action.payload
        },
        clear :()=>  initialState,
       
    },
})

export const {setEmaillog , setPasswordlog,clear}=loginslice.actions


export default loginslice.reducer