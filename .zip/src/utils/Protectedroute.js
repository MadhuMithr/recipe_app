import React from "react";
import { Outlet,Navigate } from "react-router-dom";
import {useSelector} from "react-redux"; 
const Protectedroute=({children})=>
{
    const useremail=useSelector((state)=>state?.log?.email || "");

    const userpass=useSelector((state)=>state?.log?.password|| "");

    console.log(useremail,'uname');
    
    return useremail && userpass ?
    <>
    {children}
    </>
     : <Navigate to="/login"/>;
}
export default Protectedroute;