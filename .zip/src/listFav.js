import { useSelector } from "react-redux"
import { useState } from "react"
import "./listfav.css"
import Custombutton from "./components/Custombutton";
import { useNavigate } from "react-router-dom";

const ListFav=()=>{
  //  const [inst,setInst]=useState("");
    const [showfavin,setShowfavin]=useState(null);
const it=useSelector((state)=>state.cart.itemName)
const view=(id)=>{
    setShowfavin(previd=>(previd===id?null:id));
  
}
const navigate=useNavigate();
const n=()=>{
  navigate("/Getfood");
}

return(
    <div className="main">
    <h1>favourites</h1>
     
     { it.length===0?(<h1>No favourites</h1>):((it.map((item,index)=>(
        <div className="list-details">
          <h1 id="meal-name">{item.strMeal}</h1>
          {/* <p>{item.strInstructions}</p> */}
                    <img src={item.strMealThumb} alt={item.strMeal} width="300" />
                    <Custombutton text={showfavin?"hide instructions":"view Instructions"} onClick={()=>view(index)}></Custombutton>
                    {/* <Custombutton text={"aaff"}></Custombutton> */}
                    {
                        showfavin===index &&(
                            <div>
                       
                            <p>{item.strInstructions}</p>
                            </div>
                        )
                    }

        </div>
      ))))}
       <Custombutton className={"search-page"} onClick={n}text={"search page"} ></Custombutton>
      </div>
    
    )

}
export default ListFav;